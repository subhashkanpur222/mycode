import java.util.Stack;
public class Test {
	public static String findMaxLen(String str)
	{
		String str1;
		int n = str.length();
		return str;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String str = "((()()";
        System.out.println(findMaxLen(str));
      
        str = "()(()))))";
        System.out.println(findMaxLen(str));
      
	}

}
