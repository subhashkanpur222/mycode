//   http://fahdshariff.blogspot.com/2012/08/generating-java-core-dump.html

public class CoreDumpDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
