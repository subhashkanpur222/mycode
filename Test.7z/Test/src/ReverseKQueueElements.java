import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class ReverseKQueueElements {
	static Queue<Integer>  queue; 
	static void ReverseKElements(int queuesize, int K)
	{
		Queue<Integer>  tempqueue= new LinkedList<Integer>();
		Stack<Integer> stack = new Stack<Integer>();
		 
		for(int i=0;i<queuesize-K;i++) 
			tempqueue.add(queue.remove());
		/*
		while (tempqueue.isEmpty()!=true)
		{
			System.out.println(tempqueue.remove());
		}
		
		System.out.println("hi");
		while (queue.isEmpty()!=true)
		{
			System.out.println(queue.remove());
		}*/
		
		
		while (queue.isEmpty()!=true)
		{
			stack.push(queue.remove());
		}
		
		
		//for(int i=queuesize-K;i<queuesize;i++) 
			//stack.push(queue.remove());
		//System.out.println(stack.size());
		
		//for(int i=queuesize-K;i<queuesize;i++)
			//System.out.println(stack.peek());
			
		//for(int i=0;i<queuesize-K;i++)
			//queue.add(tempqueue.remove());
		while(tempqueue.isEmpty()!=true)
			queue.add((tempqueue.remove()));
		
		while(stack.isEmpty()!=true)
		{
			queue.add(stack.peek());
			stack.pop();
			
		}
		
		while(queue.isEmpty()!=true)
			System.out.println(queue.remove());
		
		
	//	for(int i=0;i<queuesize-K;i++)
		//	System.out.println(queue.remove());
	}
	public static void main(String[] args) {		
		queue = new LinkedList<Integer>();
		queue.add(1);
		queue.add(2);
		queue.add(3);
		queue.add(4);
		queue.add(5);
		queue.add(6);
		queue.add(7);
		queue.add(8);
		int queuesize=queue.size();
		ReverseKElements(queuesize, 5);
	}

}
