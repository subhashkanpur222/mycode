package com.luv2code.designpattern;
/*
 * this program is for Creational builder design pattern
 */
class Beverage{
	private int water;
	private int sugar;
	private int powderQuantity;
	private int milk;
	private String beverageName;
	public int getWater() {
		return water;
	}
	public void setWater(int water) {
		this.water = water;
	}
	public int getSugar() {
		return sugar;
	}
	public void setSugar(int sugar) {
		this.sugar = sugar;
	}
	public int getPowder() {
		return powderQuantity;
	}
	public void setPowder(int powder) {
		this.powderQuantity = powderQuantity;
	}
	public int getMilk() {
		return milk;
	}
	public void setMilk(int milk) {
		this.milk = milk;
	}
	public String getBeverageName() {
		return beverageName;
	}
	public void setBeverageName(String beverageName) {
		this.beverageName = beverageName;
	}
	public String toString()
	{
			return "Hot " + beverageName + "!!!!  [" + water + " ml of water, " + milk + "ml of milk, " + sugar
			                + " gm of sugar, " + powderQuantity + " gm of " + beverageName + "]\n";
	}
}



/* BeverageBuilder is a blue print for any Class that wants to create
* Beverage. It will have different subClass implementations of BeverageBuilder
* for different beverages[e.g. coffee,tea,Horlicks etc].
*/
abstract class BeverageBuilder{
	private Beverage beverage;
	public Beverage getBeverage()
	{
			return beverage;
	}

	public void setBeverage( Beverage beverage )
	{
			this.beverage = beverage;
	}
	/*
	 * Template method that creates Beverage Object and returns Beverage
	 * Object after adding components in required proportion.
	 */
	public final Beverage buildBeverage()
	{
			Beverage beverage = createBeverage();
			setBeverage(beverage);
			setBeverageType();
			setWater();
			setMilk();
			setSugar();
			setPowderQuantity();
			return beverage;
	}
	abstract void setBeverageType();

	abstract void setWater();

	abstract void setMilk();

	abstract void setSugar();

	abstract void setPowderQuantity();

	abstract Beverage createBeverage();
}

class TeaBuilder extends BeverageBuilder{
	Beverage createBeverage()
	{
			return new Beverage();
	}
	void setBeverageType()
	{
			System.out.println("Tea");
			getBeverage().setBeverageName("Tea");
	}
	void setWater()
	{
		System.out.println("Step 1: Boiling water");
		getBeverage().setWater(40);
	}
	void setMilk()
	{
		System.out.println("Step 2: Adding milk");
		getBeverage().setMilk(40);
	}
	void setSugar()
	{
		System.out.println("Step 3: Adding Sugar");
		getBeverage().setSugar(40);
	}
	void setPowderQuantity()
	{
		System.out.println("Step 4: Adding tea");
		getBeverage().setPowder(40);
	}
}

class CoffeeBuilder extends BeverageBuilder{
	Beverage createBeverage()
	{
		return new Beverage();
	}
	void setBeverageType()
	{
		System.out.println("cofee");
		getBeverage().setBeverageName("Cofee");
	}
	void setWater()
	{
		System.out.println("Step 1: Boiling Water");
		getBeverage().setWater(50);
	}
	void setMilk()
	{
		System.out.println("Step 2: Adding milk");
		getBeverage().setMilk(50);
	}
	void setSugar()
	{
		System.out.println("Step 3: Adding Sugar");
		getBeverage().setSugar(50);
	}
	void setPowderQuantity()
	{
		System.out.println("Step 4: Adding cofee");
		getBeverage().setPowder(50);
	}
}


class HotelWaiter{
	public static Beverage takeOrder(String beverageType)
	{
		BeverageBuilder beverageBuilder = null;
		if(beverageType.equalsIgnoreCase("Tea"))
		{
			beverageBuilder = new TeaBuilder();
		}
		if(beverageType.equalsIgnoreCase("Coffee"))
		{
			beverageBuilder = new CoffeeBuilder();
		}
		
		return beverageBuilder.buildBeverage();
	}
}

public class CreationalBuilderDesignPatternDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Beverage tea = HotelWaiter.takeOrder("Tea");
		System.out.println(tea);
		
		
		Beverage coffee = HotelWaiter.takeOrder("Coffee");
		System.out.println(coffee);
		
	}
}
