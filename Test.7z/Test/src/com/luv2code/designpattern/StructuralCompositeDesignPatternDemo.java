package com.luv2code.designpattern;

import java.util.ArrayList;


//SoftwareEngineer class is the Leaf node [i.e. it cann't have other objects below it]
class SoftwareEngineer implements IEmployee{
	private String name;
	private int monthlySalary;
	
	// Employee designation Can be Dev Software Engineer, QA Software Engineer
	private String designation;

	public SoftwareEngineer( String name, int monthlySalary, String designation )
	{
			super();
			this.name = name;
			this.monthlySalary = monthlySalary;
			this.designation = designation;
	}
	public String getName()
	{
			return name;
	}

	public void setName( String name )
	{
			this.name = name;
	}

	public int getMonthlySalary()
	{
			return monthlySalary;
	}

	public void setMonthlySalary( int monthlySalary )
	{
			this.monthlySalary = monthlySalary;
	}

	public String getDesignation()
	{
			return designation;
	}

	public void setDesignation( String designation )
	{
			this.designation = designation;
	}

	@Override
	public int getYearlySalary()
	{
			return monthlySalary * 12;
	}
}

interface IEmployee
{
		public int getYearlySalary();

}
//Employee class is the Composite node [i.e. it can have other objects below it]
class Employeen implements IEmployee{
	private String  name;
	private int monthlySalary;
	private String designation;
	private ArrayList<IEmployee> subordinateList = new ArrayList<IEmployee>();
	
	public Employeen( String name, int monthlySalary, String designation )
	{
			super();
			this.name = name;
			this.monthlySalary = monthlySalary;
			this.designation = designation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMonthlySalary() {
		return monthlySalary;
	}

	public void setMonthlySalary(int monthlySalary) {
		this.monthlySalary = monthlySalary;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public ArrayList<IEmployee> getSubordinateList() {
		return subordinateList;
	}

	public void setSubordinateList(ArrayList<IEmployee> subordinateList) {
		this.subordinateList = subordinateList;
	}
	
	@Override
	public int getYearlySalary()
	{
			return monthlySalary * 12;
	}
	public void addSubordinate( IEmployee employee )
	{
			subordinateList.add(employee);
	}
	public void removeSubordinate( IEmployee employee )
	{
			subordinateList.remove(employee);
	}
	public ArrayList<IEmployee> getChilds()
	{
			return getSubordinateList();
	}
}

public class StructuralCompositeDesignPatternDemo {

	public static void main(String[] args) {
		

	}

}
