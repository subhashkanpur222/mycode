package com.luv2code.designpattern;

// Receiver
class WorldDocument
{
	public void open()
	{
		System.out.println("Document is opened");
	}
	public void save()
	{
		System.out.println("Document is saved");
	}
	public void close()
	{
		System.out.println("Document is closed");
	}
}

interface Command
{
	public void execute();	
}

class Opencommand implements Command
{
	WorldDocument wd;
	public Opencommand(WorldDocument wd)
	{
		this.wd = wd;
	}
	@Override
	public void execute() {
		wd.open();
	}	
}
class Savecommand implements Command
{
	WorldDocument wd;
	public Savecommand(WorldDocument wd)
	{
		this.wd = wd;
	}
	@Override
	public void execute() {
		wd.save();
	}	
}
class Closecommand implements Command
{
	WorldDocument wd;
	public Closecommand(WorldDocument wd)
	{
		this.wd = wd;
	}
	@Override
	public void execute() {
		wd.close();
	}	
}

//Invoker
class MenuOptions
{
	Command Opencommand;
	Command Savecommand;
	Command Closecommand;
	public MenuOptions(Command oc,Command sc,Command cc)
	{
		this.Opencommand = oc;
		this.Savecommand = sc;
		this.Closecommand = cc;
	}
	public void clickOpen()
	{
		Opencommand.execute();
	}
	public void clickSave()
	{
		Savecommand.execute();
	}
	public void clickClose()
	{
		Closecommand.execute();
	}
	
}

public class BehavioralCommandDesignPattern {

	public static void main(String[] args) {
		WorldDocument wd = new WorldDocument();
		Command oc = new Opencommand(wd);
		Command sc = new Savecommand(wd);
		Command cc = new Closecommand(wd);
		MenuOptions menu = new MenuOptions(oc,sc,cc);
		menu.clickOpen();
		menu.clickSave();
		menu.clickSave();
		
	}
}
