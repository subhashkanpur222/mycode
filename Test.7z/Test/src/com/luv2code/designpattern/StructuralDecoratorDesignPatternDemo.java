package com.luv2code.designpattern;

//Decorator patter using pizza example. Decorator pattern adds vegetables or chiecken as per decorator pattern.

interface Pizza
{
		public String makePizza();
}

class PlainPizza implements Pizza
{

		@Override
		public String makePizza()
		{
				return "Plain Pizza done";
		}
}

class PizzaDecorator implements Pizza
{
		protected Pizza pizza;
		public PizzaDecorator( Pizza pizza )
		{
				this.pizza = pizza;
		}
		public String makePizza()
		{
				return pizza.makePizza();
		}
}

class VegPizzaDecorator extends PizzaDecorator
{
		public VegPizzaDecorator( Pizza pizza )
		{
				super(pizza);
		}
		public String makePizza()
		{
				return pizza.makePizza() + addVegetableAndCheese();
		}
		private String addVegetableAndCheese()
		{
				return ",Vegetable and Cheese added";
		}
}

class ChickenPizzaDecorator extends PizzaDecorator
{
		public ChickenPizzaDecorator( Pizza pizza )
		{
				super(pizza);
		}
		public String makePizza()
		{
				return pizza.makePizza() + addChickenAndCheese();
		}
		private String addChickenAndCheese()
		{
				return ",Chicken and Cheese added";
		}
}

public class StructuralDecoratorDesignPatternDemo {

	public static void main(String[] args) {
		PlainPizza plainPizzaObj = new PlainPizza();
		String plainPizza = plainPizzaObj.makePizza();
		System.out.println(plainPizza);
		
		String chickenPizza = new ChickenPizzaDecorator(plainPizzaObj).makePizza();
		System.out.println("\n'" + chickenPizza + "' using ChickenPizzaDecorator");
		
		String vegPizza = new VegPizzaDecorator(plainPizzaObj).makePizza();
		System.out.println("\n'" + vegPizza + "' using VegPizzaDecorator");
	}

}
