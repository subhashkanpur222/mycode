/**
 * https://www.youtube.com/watch?v=8jy_fXI1OzA&list=PLzKjgAhVqCzZqg23sGDn5GMaUikNXTkfW&index=18
 * https://www.geeksforgeeks.org/strategy-pattern-set-1/
 * https://www.geeksforgeeks.org/adapter-pattern/
 * https://www.geeksforgeeks.org/iterator-pattern/
 * 
 * https://ramj2ee.blogspot.com/
 * Creational Design pattern=> https://www.youtube.com/watch?v=bTQ3owJOMFM&list=PLmCsXDGbJHdhULIoYzIIIeFFJSo1NlMbN
 * 
 * 1. object pool Pattern: For creating the expensive objects like db connect object. This will share the object to improve the performace.
 *    Object should be reusable and should be shared with multiple clients.
 */
/**
 * @author subhasku
 *
 */
package com.luv2code.designpattern;