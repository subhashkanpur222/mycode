package com.luv2code.designpattern;

abstract class HouseTemplate{
	final void buildHouse()
	{
		buildFoundation();
		buildPillors();
		buildWalls();
		buildWindows();
	}
	public abstract void buildFoundation();
	public abstract void buildPillors();
	public abstract void buildWalls();
	public abstract void buildWindows();
}

class WoddenHouse extends HouseTemplate{
	@Override
	public void buildFoundation() {
		System.out.println("Building foundation with cement,iron rods,sand and wood");		
	}
	@Override
	public void buildPillors() {
		System.out.println("Building Pillars with Wood coating");		
	}
	@Override
	public void buildWalls() {
		System.out.println("Building Wooden Walls");		
	}
	@Override
	public void buildWindows() {
		System.out.println("Building Wooden Windows");		
	}	
} 

class GlassHouse extends HouseTemplate{

	@Override
	public void buildFoundation() {
		System.out.println("Building foundation with cement,iron rods and sand");
	}

	@Override
	public void buildPillors() {
		System.out.println("Building Pillars with glass coating");
	}

	@Override
	public void buildWalls() {
		System.out.println("Building Glass Walls");
	}

	@Override
	public void buildWindows() {
		System.out.println("Building Glass Windows");
	}	
}



public class BehavioralTemplateDesignPattern {

	public static void main(String[] args) {
		HouseTemplate wt = new WoddenHouse();
		System.out.println("Building Wodden House:");
		wt.buildHouse();
		
		System.out.println("============================================================================================");
		
		System.out.println("Building Glass House:");
		HouseTemplate gt = new GlassHouse();
		gt.buildHouse();
	}

}
