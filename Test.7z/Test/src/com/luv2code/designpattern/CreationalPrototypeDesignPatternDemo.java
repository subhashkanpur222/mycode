package com.luv2code.designpattern;

import java.util.Hashtable;

/*
 * Prototype design pattern is used to create object by cloning existing object  
 * and this improves performance as object and nested object creation is avoided.  * 
 * If there is not object is present to clone, new object is created.
 */
interface Animal extends Cloneable{
	 public Animal clone();
}

class Dogtail{
	String tailLength;
	public void setTailLength(String tailLength)
	{
		this.tailLength = tailLength;
	}
	public String getTailLength()
	{
		return this.tailLength;
	}
	@Override
    public String toString()
    {
	        return "Dogtail [tailLength=" + tailLength + "]";
    }
}

class Dogleg{
	int numberofLegs;
	public void setNumberofLegs(int numberofLegs)
	{
		this.numberofLegs = numberofLegs;
	}
	public int getNumberofLegs()
	{
		return this.numberofLegs;
	}
	@Override
    public String toString()
    {
	        return "Dogleg [numberOflegs=" + numberofLegs + "]";
    }
}

class Dogear{
	int numberofEar;
	public int getNumberofEar() {
		return numberofEar;
	}
	public void setNumberofEar(int numberofEar) {
		this.numberofEar = numberofEar;
	}
	@Override
    public String toString()
    {
	        return "Dogear [numberOfEars=" + numberofEar + "]";
    }
}

class Dogeye{
	int numberofEyes;
	public int getNumberofEyes() {
		return numberofEyes;
	}
	public void setNumberofEyes(int numberofEyes) {
		this.numberofEyes = numberofEyes;
	}
	@Override
    public String toString()
    {
	        return "Dogeye [numberOfEyes=" + numberofEyes + "]";
    }
}

 class Dog implements Animal{
	 Dogeye dogeye;
	 Dogear dogear;
	 Dogleg dogleg;
	 Dogtail dogtail;
	 String name;
	 int age;
	 String color;
	 
	 public Dog(String name, int age, String color, Dogtail dogtail, Dogleg dogleg, Dogear dogear, Dogeye dogeye)
	 {
		 this.color = color;
		 this.age = age;
		 this.name = name;
		 this.dogear = dogear;
		 this.dogeye = dogeye;
		 this.dogtail = dogtail;
		 this.dogleg = dogleg;
	 }
	 public Animal clone()
	 {
		 Dog dogObject = null;
		 try
			{
					dogObject = (Dog) super.clone();
			}
			catch( CloneNotSupportedException e )
			{
					e.printStackTrace();
			}
			return dogObject;		 
	 }

	public Dogeye getDogeye() {
		return dogeye;
	}

	public void setDogeye(Dogeye dogeye) {
		this.dogeye = dogeye;
	}

	public Dogear getDogear() {
		return dogear;
	}

	public void setDogear(Dogear dogear) {
		this.dogear = dogear;
	}

	public Dogleg getDogleg() {
		return dogleg;
	}

	public void setDogleg(Dogleg dogleg) {
		this.dogleg = dogleg;
	}

	public Dogtail getDogtail() {
		return dogtail;
	}

	public void setDogtail(Dogtail dogtail) {
		this.dogtail = dogtail;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}	 
}

class AnimalCache{
	static Hashtable<String, Dog> AnimalMap = new Hashtable<String, Dog>();
	public static Animal getAnimal( String animalType )
	{
		Dog dog = (Dog) AnimalMap.get(animalType);
		if( dog == null )
		{
				Dogleg dogleg = new Dogleg();
				dogleg.setNumberofLegs(4);

				Dogear dogear = new Dogear();
				dogear.setNumberofEar(2);

				Dogtail dogtail = new Dogtail();
				dogtail.setTailLength("long");

				Dogeye dogeye = new Dogeye();
				dogeye.setNumberofEyes(2);

				dog = new Dog("Tommy", 3, "White", dogtail, dogleg, dogear, dogeye);
				AnimalMap.put("dog", dog);
				System.out.println("New Dog Object is created and return\n");
				return dog;
		}
		System.out.println("\nCloned Dog Object is created and return\n");
		return dog.clone();
	}	
}
 
public class CreationalPrototypeDesignPatternDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnimalCache.getAnimal("dog");
		AnimalCache.getAnimal("dog");
	}

}
