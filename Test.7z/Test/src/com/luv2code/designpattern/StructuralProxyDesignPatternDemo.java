package com.luv2code.designpattern;

/*
 * In Proxy design pattern one object contains another class object and support the feature of that class object.
 */

interface IFolder
{
	public void performReadWriteOperation();
}

class Folder implements IFolder
{

	@Override
	public void performReadWriteOperation() {
		System.out.println("Read and Write operation performed successfully");
	}
}

class FolderProxy implements IFolder
{
	Person person;
	public FolderProxy(Person person)
	{
		this.person = person;
	}
	@Override
	public void performReadWriteOperation() {// TODO Auto-generated method stub
		if(person.getRole().equalsIgnoreCase("CEO") || person.getRole().equalsIgnoreCase("manager"))
		{
			Folder f = new Folder();
			f.performReadWriteOperation();
		}
		else
			System.out.println("Read and write operation is not permitted");
	}
	
}

//This class has person information and will be used in other classes for determining the role associated with an user.
class Person
{
	String userName;
	String password;
	String role;
	public Person(String userName, String password, String role)
	{
		this.userName = userName;
		this.password = password;
		this.role = role;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
}

public class StructuralProxyDesignPatternDemo {

	public static void main(String[] args) {
	Person p1 = new Person("subhash", "abc", "developer");	
	Person p2 = new Person("Ramesh", "abc", "CEO");	
	Person p3 = new Person("Raja", "abc", "manager");	
	FolderProxy fp = new FolderProxy(p3);
	//fp.setPerson(p1);
	fp.performReadWriteOperation();
	}
}
