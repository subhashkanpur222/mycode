package com.luv2code.designpattern;

public class CreationalSingletonPattern {
	public static CreationalSingletonPattern csp= null;
	private CreationalSingletonPattern()
	{
		
	}	
	
	static synchronized CreationalSingletonPattern getObject()
	{
		if(csp == null)
			csp = new CreationalSingletonPattern();
		
			return csp;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*System.out.println(CreationalSingletonPattern.getObject());
		System.out.println(CreationalSingletonPattern.getObject());
		System.out.println(CreationalSingletonPattern.getObject());
		System.out.println(CreationalSingletonPattern.getObject());
		System.out.println(CreationalSingletonPattern.getObject());*/
		
		Thread t1 = new Thread (new Runnable() {
			@Override
			public void run()
			{
				System.out.println(CreationalSingletonPattern.getObject());
			}
		});
		
		Thread t2 = new Thread (new Runnable() {
			@Override
			public void run()
			{
				System.out.println(CreationalSingletonPattern.getObject());
			}
		});
		t1.start();
		t2.start();
	}

}
