package com.luv2code.designpattern;
//https://www.youtube.com/watch?v=8jy_fXI1OzA&index=59&list=PLmCsXDGbJHdhJF8xtdsKlFfOuhSMZLNEz
//Object behavior changes with change in state. ex: ATM machine
interface AtmMachineState
{
	public void insertDebitCard();
	public void ejectDebitCard();
	public void enterPinandWithdrawMoney();	
}

class ATMMachine implements AtmMachineState{
	AtmMachineState atmmachinestate = null;
	
	public ATMMachine()
	{
		this.atmmachinestate = new NoDebitCardState();
	}
	public AtmMachineState getAtmmachinestate() {
		return atmmachinestate;
	}

	public void setAtmmachinestate(AtmMachineState atmmachinestate) {
		this.atmmachinestate = atmmachinestate;
	}

	@Override
	public void insertDebitCard() {
		atmmachinestate.insertDebitCard();
		if( atmmachinestate instanceof NoDebitCardState )
		{

				AtmMachineState hasDebitCardState = new HasDebitCardState();
				setAtmmachinestate(hasDebitCardState);
				System.out.println("ATM Machine internal state has been moved to : "
				                + atmmachinestate.getClass().getName());
		}
	}

	@Override
	public void ejectDebitCard() {
		atmmachinestate.ejectDebitCard();
		if( atmmachinestate instanceof HasDebitCardState )
		{

				AtmMachineState noDebitCardState = new NoDebitCardState();
				setAtmmachinestate(noDebitCardState);
				System.out.println("ATM Machine internal state has been moved to : "
				                + atmmachinestate.getClass().getName());
		}
	}

	@Override
	public void enterPinandWithdrawMoney() {
		atmmachinestate.enterPinandWithdrawMoney();
	}	
}

class NoDebitCardState implements AtmMachineState{

	@Override
	public void insertDebitCard() {
		System.out.println("Debit card is inserted successfully!!!");
	}

	@Override
	public void ejectDebitCard() {
		System.out.println("There is no debit card inserted, opertion not permitted");
	}

	@Override
	public void enterPinandWithdrawMoney() {
		System.out.println("There is no debit card inserted, opertion not permitted");
	}
	
}

class HasDebitCardState implements AtmMachineState{

	@Override
	public void insertDebitCard() {
		System.out.println("There is already inserted, opertion not permitted");
	}

	@Override
	public void enterPinandWithdrawMoney() {
		System.out.println("Pin enter and money is withdrawn successfully!!!");
	}
	
	@Override
	public void ejectDebitCard() {
		System.out.println("Debit card is ejected successfully!!!");
	}

}
public class BehavioralStateDesignPattern {
	public static void main(String[] args) {
		ATMMachine atm = new ATMMachine();
		System.out.println("ATM Machine Current state : "+ atm.getAtmmachinestate().getClass().getName());
		atm.enterPinandWithdrawMoney();
		atm.ejectDebitCard();
		atm.insertDebitCard();
		
		
		System.out.println("\nATM Machine Current state : "
                + atm.getAtmmachinestate().getClass().getName());
		System.out.println();

		atm.enterPinandWithdrawMoney();
		atm.insertDebitCard();
		atm.ejectDebitCard();
	}

}
