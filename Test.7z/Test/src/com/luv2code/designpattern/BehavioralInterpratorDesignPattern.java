package com.luv2code.designpattern;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Scanner;

class Context
{
	String expression;
	Date date;
	public String getExpression() {
		return expression;
	}
	public void setExpression(String expression) {
		this.expression = expression;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
}

interface Interprator
{
	void expressionEvaluator(Context con);
}


class DayexpressionEvaluator implements Interprator
{

	@Override
	public void expressionEvaluator(Context con) {
		String expression = con.getExpression();
		Date date = con.getDate();
		Integer day = new Integer(date.getDay());
		String tempExpression = expression.replaceAll("DD", day.toString());
		con.setExpression(tempExpression);
	}	
}

class MonthexpressionEvaluator implements Interprator
{

	@Override
	public void expressionEvaluator(Context con) {
		String expression = con.getExpression();
		Date date = con.getDate();
		Integer month = new Integer(date.getMonth()+1);
		String tempExpression = expression.replaceAll("MM", month.toString());
		con.setExpression(tempExpression);
	}
	
}

class YearexpressionEvaluator implements Interprator
{

	@Override
	public void expressionEvaluator(Context con) {
		String expression = con.getExpression();
		Date date = con.getDate();
		Integer year = new Integer(date.getYear()+1900);
		String tempExpression = expression.replaceAll("YYYY", year.toString());
		con.setExpression(tempExpression);
	}
	
}

public class BehavioralInterpratorDesignPattern {

	public static void main(String[] args) {
		System.out.println("Please select the Expression  : 'MM-DD-YYYY' or 'YYYY-MM-DD'");
		Scanner scanner = new Scanner(System.in);
		String expression = scanner.next();
		Context context = new Context();
		context.setExpression(expression);
		context.setDate(new Date(0));
		
		ArrayList<Interprator> expressionOrderList = getExpressionOrder(context);
		
	}
}
