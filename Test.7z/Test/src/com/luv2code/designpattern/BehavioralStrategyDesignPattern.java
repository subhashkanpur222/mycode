package com.luv2code.designpattern;

interface TravelStrategy{
	public void gotoAirport();
}

class TravelContext implements TravelStrategy{
	TravelStrategy travelstrategy = null;
	public void setTravelStrategy(TravelStrategy travelstrategy)
	{
		this.travelstrategy = travelstrategy;
	}
	@Override 
	public void gotoAirport()
	{
		travelstrategy.gotoAirport();
	}
}

class TaxiTravelStrategy implements TravelStrategy{

	@Override
	public void gotoAirport() {
		System.out.println("Go to Airport using Taxi");		
	}	
}
class AutoTravelStrategy implements TravelStrategy{

	@Override
	public void gotoAirport() {
		System.out.println("Go to Airport using Auto");		
	}	
}
class BusTravelStrategy implements TravelStrategy{

	@Override
	public void gotoAirport() {
		System.out.println("Go to Airport using Bus");		
	}	
}
class TrainTravelStrategy implements TravelStrategy{

	@Override
	public void gotoAirport() {
		System.out.println("Go to Airport using Train");		
	}	
}

public class BehavioralStrategyDesignPattern {

	public static void main(String[] args) {
		TravelContext ts = new TravelContext();
		ts.setTravelStrategy(new TaxiTravelStrategy());
		ts.gotoAirport();
	}

}
