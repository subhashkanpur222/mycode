package com.luv2code.designpattern;

import java.util.ArrayList;

/*
 * Observer design pattern state of object depends on state of other objects. there is one to many mapping in between object.
 */
abstract class Observer{
	Subject subj;
	public abstract void update();
}

class Octalobserver extends Observer{

	public Octalobserver(Subject subj)
	{
		this.subj = subj;
		subj.registerObserver(this);
	}
	@Override
	public void update() {
		System.out.println("Current value of Octal state is: "+Integer.toOctalString(subj.getState()));		
	}
}

class Binaryobserver extends Observer{

	public Binaryobserver(Subject subj)
	{
		this.subj = subj;
		subj.registerObserver(this);
	}
	@Override
	public void update() {
		System.out.println("Current value of Binary state is "+Integer.toBinaryString(subj.getState()));		
	}		
}

class Hexaobserver extends Observer{
	public Hexaobserver(Subject subj)
	{
		this.subj = subj;
		subj.registerObserver(this);
	}
	@Override
	public void update() {
		System.out.println("Current value of Hexadecimal state is "+Integer.toHexString(subj.getState()));		
	}	
}

class Subject{
	private int state;
	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
		notifyAllObservers();
	}

	ArrayList <Observer> al = new ArrayList<Observer>();
	
	public void registerObserver(Observer obsrvr)
	{
		al.add(obsrvr);
	}
	
	public void removeObserver(Observer obsrvr)
	{
		al.remove(obsrvr);
	}
	
	public void notifyAllObservers() 
	{
		for(Observer itr: al)
		{
			itr.update();
		}
	}
}

public class BehavioralObserverDesignPattern {

	public static void main(String[] args) {
		Subject sub = new Subject();
		Observer oo= new Octalobserver(sub);
		Observer bo = new Binaryobserver(sub);
		Observer ho = new Hexaobserver(sub);
		sub.setState(10);
		
		sub.removeObserver(oo);
		sub.setState(15);
		
	}
}
