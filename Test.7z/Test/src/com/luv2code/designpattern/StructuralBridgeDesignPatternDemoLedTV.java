package com.luv2code.designpattern;
/*
 * Bridge Design Pattern separate implementation and abstraction. Any change made to abstraction will not   
 * impact implementation and vice-versa.
 */
interface LEDTV
{
public void switchOn();
public void switchoff();
public void setChannel(int channelNumber);
}

class SamsungLedTV implements LEDTV
{
	@Override
	public void switchOn() {
		System.out.println("SamsungLedTV is switched on");
	}
	@Override
	public void switchoff() {
		System.out.println("SamsungLedTV is switched off");
	}
	@Override
	public void setChannel(int channelNumber) {
		System.out.println(channelNumber+" is set in Samsung LED TV");
	}	
}

class SonyLedTV implements LEDTV
{
	@Override
	public void switchOn() {
		System.out.println("SonyLedTV is switched on");
	}

	@Override
	public void switchoff() {
		System.out.println("SonyLedTV is switched off");
	}

	@Override
	public void setChannel(int channelNumber) {
		System.out.println(channelNumber+" is set in Sonly LED TV");
	}	
}

abstract class AbstractRemoteControl
{
	LEDTV ledtv;

	abstract void switchOn();
	abstract void switchoff();
	abstract void setChannel(int channelNumber);
}

class SamsungTvRemoteControl extends AbstractRemoteControl
{
	public SamsungTvRemoteControl(LEDTV ledtv) {
		//super(ledtv);
		this.ledtv = ledtv;
		}
	@Override
	void switchOn() {
		ledtv.switchOn();		
	}
	@Override
	void switchoff() {
		ledtv.switchoff();
	}
	@Override
	void setChannel(int channelNumber) {
		ledtv.setChannel(channelNumber);
	}
}

class SonyTvRemoteControl extends AbstractRemoteControl
{

	public SonyTvRemoteControl(LEDTV ledtv) {
		//super(ledtv);
		this.ledtv = ledtv;
		}

	@Override
	void switchOn() {
		ledtv.switchOn();
	}

	@Override
	void switchoff() {
		ledtv.switchoff();
	}

	@Override
	void setChannel(int channelNumber) {
		ledtv.setChannel(channelNumber);
	}
	
}

public class StructuralBridgeDesignPatternDemoLedTV {
	public static void main(String[] args) {
		AbstractRemoteControl samTvRemote = new SamsungTvRemoteControl(new SamsungLedTV());
		samTvRemote.switchOn();
		samTvRemote.switchoff();
		samTvRemote.setChannel(139);
		AbstractRemoteControl sonyTvRemote = new SonyTvRemoteControl(new SonyLedTV());
	}
}
