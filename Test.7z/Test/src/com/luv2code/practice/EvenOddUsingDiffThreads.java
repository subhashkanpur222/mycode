package com.luv2code.practice;

class EvenOddDemo
{
	static boolean printOdd=false;
	
	public synchronized void printEven()
	{
		for(int i = 0; i<=10; i=i+2)
		{
		if(printOdd == false)
		{
			System.out.println(i + " from printEven");
			printOdd =true;
			notify();
			try {
				wait();
				//System.out.println("going for wait in eve");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}			
	}
	
	public synchronized void printOdd()
	{
		for(int j=1 ; j<10 ; j=j+2)
		{
			if(printOdd == true)
			{
			System.out.println(j + " from printOdd");
			printOdd =false;
			notify();
			try {
					wait();
					//System.out.println("going for wait in odd");
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
public class EvenOddUsingDiffThreads extends Thread{
	public static void main(String[] args) {
		EvenOddDemo t = new EvenOddDemo();
		new Thread() {
			@Override
			public void run()
			{
				t.printEven();
			}
		}.start();
		new Thread() {
			@Override
			public void run()
			{
				t.printOdd();
			}
		}.start();
	}
}
