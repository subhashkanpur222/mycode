package com.luv2code.practice;

class ThreadDemo
{
static boolean printEven =true;
public synchronized void printEven()
{
	for(int i=0; i<10; i=i+2)
	{
		if(printEven)
		{
			System.out.println(i +" from even thread");
			printEven = false;
			notifyAll();
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

public synchronized void printOdd()
{
	for(int j=1; j<10; j=j+2)
	{
		if(printEven == false)
		{
			System.out.println(j+ " from odd thread");
			printEven = true;
			notifyAll();
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
}
public class EvenOddUsingDiffThreadsRunnable{
	
	public static void main(String[] args) {
		ThreadDemo td = new ThreadDemo();
		Thread t1 = new Thread(new Runnable()
			{
				@Override
				public void run() {
					td.printEven();
				}
			}
		);
		Thread t2 = new Thread(new Runnable()
				{
					@Override
					public void run()
					{
						td.printOdd();
					}
				}
				);
		t1.start();
		t2.start();
	}	
}
