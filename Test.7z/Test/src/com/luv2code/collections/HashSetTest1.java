package com.luv2code.collections;

public class HashSetTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
