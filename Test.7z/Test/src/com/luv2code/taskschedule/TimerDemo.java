package com.luv2code.taskschedule;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

class CleanupTimerTask extends TimerTask
{

	@Override
	public void run() {
		System.out.println("Cleanup files....");
	}
	
}

public class TimerDemo {

	public static void main(String[] args) {
		CleanupTimerTask cleanUpTimerTask = new CleanupTimerTask();
		Timer timer = new Timer();
		Date firstTime = new Date(System.currentTimeMillis()+5000);
		System.out.println(firstTime);
		
		timer.scheduleAtFixedRate(cleanUpTimerTask, firstTime, 2000);
		System.out.println("Timer has scheduled cleanUpTimerTask");
	}

}
