package com.luv2code.generics;

import java.awt.List;
import java.util.ArrayList;

public class GenericTest1 {

	private Object t;
	public Object get()
	{
		return this.t;
	}
	public void set(Object t)
	{
		this.t=t;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> l1 =new ArrayList<String>();
		l1.add("Subhash");
		//l1.add(new Integer(10));		
		//System.out.println(l1);
		for(Object obj : l1){
			//type casting leading to ClassCastException at runtime
		    String str=(String) obj; 
		}
		
		
		GenericTest1 type = new GenericTest1();
		type.set("Subhash");
		type.set(10);
		String str1 =(String)type.get();
	}

}
