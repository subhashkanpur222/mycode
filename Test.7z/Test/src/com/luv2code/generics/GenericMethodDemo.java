package com.luv2code.generics;

public class GenericMethodDemo {
	static<T> boolean isEquall(GenericClassDemo<T> g1, GenericClassDemo<T> g2)
	{
		return g1.get().equals(g2.get());
	}

	public static void main(String[] args) {
		GenericClassDemo<String> g1 =  new GenericClassDemo<>();
		g1.set("Subhash");
		
		GenericClassDemo g2 =  new GenericClassDemo();
		g2.set(10);
		
		boolean isEquall = GenericMethodDemo.isEquall(g1, g2);
		System.out.println(isEquall);
	}

}
