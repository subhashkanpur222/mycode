/**
 * https://www.journaldev.com/1663/java-generics-example-method-class-interface
 */
/**
 * @author subhasku
 *
 */
package com.luv2code.generics;