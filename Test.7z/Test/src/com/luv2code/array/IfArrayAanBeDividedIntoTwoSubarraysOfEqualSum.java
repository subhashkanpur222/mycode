package com.luv2code.array;

// https://www.geeksforgeeks.org/find-if-array-can-be-divided-into-two-subarrays-of-equal-sum/

public class IfArrayAanBeDividedIntoTwoSubarraysOfEqualSum {
	static void printArray(int arr[], int start, int end)
	{
		for (int i = start; i<= end ; i++)
			System.out.println(" "+arr[i]);
		
	}
	static void divideArray(int arr[], int n)
	{
		int sumFromStart[] = new int[n];
		int sumFromEnd[] = new int[n];
		for(int i = 0;i<n;i++)
		{
			sumFromStart[i] = 0; sumFromEnd[i]= 0;
		}
		for(int i = 0;i<n;i++)
			sumFromStart[i] =sumFromStart[i]+arr[i];
		
		for(int i =n-1;i>=0 ;i--)
			sumFromEnd[i] = sumFromEnd[i]+arr[i];
		
	}
	public static void main(String[] args) {
		int arr[] = {6, 1, 3,3, 2, 5}; 
		int n = arr.length; 

		divideArray(arr, n); 
	}

}
