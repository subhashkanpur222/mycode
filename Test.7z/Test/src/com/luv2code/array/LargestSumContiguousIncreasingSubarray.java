package com.luv2code.array;
// https://www.geeksforgeeks.org/largest-sum-contiguous-increasing-subarray/ 


public class LargestSumContiguousIncreasingSubarray {
	static int largestSum(int arr[], int n)
	{
		int largestSum = 0, sumSoFar = 0;
		for(int i =0 ;i <n-1 ;i++)
		{
						
			if(arr[i+1] > arr[i])
				sumSoFar += arr[i];
			else if(sumSoFar+arr[i] > largestSum)
				{
					largestSum = sumSoFar+arr[i];
					sumSoFar=0;
					
				}
			
		}
		
		return largestSum;
	}
	public static void main(String[] args) {
		int arr[] = {38, 7, 8, 10, 12}; 
        int n = arr.length; 
        System.out.println("Largest sum = " +  largestSum(arr, n)); 
	}
}
