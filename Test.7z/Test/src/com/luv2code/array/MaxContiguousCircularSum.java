package com.luv2code.array;

public class MaxContiguousCircularSum {
	static int maxCircularSum(int arr[])
	{
		int n = arr.length;
		int sum=0,maxSum=0,startSum=0,startEndIndex=0;
		
		for(int i = 0; i<n;i++)
		{
			sum =sum+arr[i];
			if(sum > startSum)
				{
					startSum = sum;
					startEndIndex = i;
				}
			else
				break;
		}
		sum = 0;
		for(int i =startEndIndex+1; i<n;i++)
		{
			sum = sum+arr[i];
			if(sum > maxSum)
				maxSum = sum;
			else if(sum < 0)
				sum = 0;
		}
		
		if(maxSum+startSum >  maxSum)
			return maxSum+startSum;
		else
			return maxSum;
	}
	public static void main(String[] args) {
		 int a[] =  {11, 10, -20, 5, -3, -5, 8, -13, 10}; 
         System.out.println("Maximum circular sum is " + maxCircularSum(a)); 
	}

}
