package com.luv2code.array;
//https://www.geeksforgeeks.org/even-numbers-even-index-odd-numbers-odd-index/

public class EvenOddPositionTheirValue {
	public static void printArray(int arr[], int n)
	{
		for(int i=0;i<n;i++)
			System.out.print(arr[i]+" ");
	}
	
	public static void arrangeOddAndEven(int arr[], int n)
	{
		boolean flageven = false,flagodd = false;
		int i=0,j=1;
		System.out.println(" at 15");
		while(true)
		{
			//System.out.println("in while ");
			while ((i<n) && (arr[i]%2 == 0))
			{
				System.out.println(" at 21");
				i=i+2;
				flageven=true;
				
			}
			
			while ((j<n) && (arr[j]%2 == 1))
			{
				System.out.println(" at 28");
				j=j+2;
				flagodd=true;
				
			}
			
			if(i<n && j<n)
			{
				System.out.println("hi");
				int temp=0;
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]= temp;
			}
			else 
				break;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 3, 6, 12, 1, 5, 8 }; 
	    int n = 6; 
	  
	    System.out.print("Original Array: "); 
	    printArray(arr, n); 
	  
	    arrangeOddAndEven(arr, n); 
	  
	    System.out.print("\nModified Array: "); 
	    printArray(arr, n); 

	}

}
