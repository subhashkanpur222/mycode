package com.luv2code.exceptionhandling;

class LowBalanceException extends Exception{
	public LowBalanceException(String message)
	{
		//System.out.println("Withdrawl amount is more than current balance");
		super(message);
	}
}
