package com.luv2code.graph;

public class DetectCycleInGrapthDFS {
	static boolean isCyclic = false;
	static int graphNodes = 6, length;
	static int currentNode;
	static int graph[][] = new int [][] {{0,0,0,0,0,0},
		 {0,0,0,0,0,0},
		 {0,0,0,1,0,0},
		 {0,1,0,0,0,1},
		 {1,1,0,0,0,0},
		 {1,0,1,0,0,0}};
		 
	static void DetectCycleInGrapth(int currLocalNode)
	{
		//length is used to make sure that we are coming to current node after visiting other nodes
		if(currLocalNode == currentNode && length > 0)
		{
			isCyclic =true;
			return;
		}
		length++;
		for(int i=0; i<graphNodes && isCyclic ==false; i++)
		{
			if (graph[currLocalNode][i] == 1)
			{
				System.out.println("currLocalNode is: "+currLocalNode +" i is: "+i );
				DetectCycleInGrapth(i);
			}
		}
		
	}
	public static void main(String[] args) {
		for(int i=0; i<graphNodes; i++)
		{
			currentNode = i;
			length = 0;
			DetectCycleInGrapth(currentNode);
		}
		if(isCyclic)
			System.out.println("Grapth is cyclic");
		else
			System.out.println("Grapth is not cyclic");
	}
}
