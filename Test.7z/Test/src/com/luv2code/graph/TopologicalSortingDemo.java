package com.luv2code.graph;

public class TopologicalSortingDemo {
	static int graphNode = 6, count =0;
	static int graph[][] = new int [][] {{0,0,0,0,0,0},
										 {0,0,0,0,0,0},
										 {0,0,0,1,0,0},
										 {0,1,0,0,0,0},
										 {1,1,0,0,0,0},
										 {1,0,1,0,0,0}};
										 
	static void printTopologicalOrder()
	{
		int inDegree[] = new int[6];
		boolean nodeVisited[] = new boolean[6];
		//initialize indegree
		for(int i=0; i<graphNode; i++)
			{inDegree[i] = 0; nodeVisited[i] = false;}
		
		//calculate indegree
		for(int i=0; i<graphNode; i++)
		{
			for(int j=0; j<graphNode; j++)
			{
				if(graph[i][j] == 1)
					inDegree[j] = inDegree[j]+1;
			}
		}
		
		//
		while(count < graphNode)
		{
			for(int j=0; j<graphNode; j++)
			{
				if(nodeVisited[j] == false && inDegree[j] == 0)
				{
					System.out.println(j);
					nodeVisited[j] = true;	

					for(int i = 0; i< graphNode; i++)
					{
						if(graph[j][i] == 1)
						{
							inDegree[i] -= 1;
						}
					}
				}
			}
			count++;
		}		
	}
	public static void main(String[] args) {
		printTopologicalOrder();
	}

}
