package com.luv2code.graph;

public class NumberofIslands {
	static int count=0;
	static boolean visited[][]=new boolean[5][5];
	static int arr[][] = new int[][] {{1, 1, 0, 0, 0},
        							  {0, 1, 0, 0, 1},
        							  {1, 0, 0, 1, 1},
        							  {0, 0, 0, 0, 0},
        							  {1, 0, 1, 0, 1}}; 
    static boolean isSafe(int i, int j)
    {
    	  	
    	return (i>=0 && i<5) && (j>=0 && j<5) && visited[i][j]==false && (arr[i][j]==1);
    }
	static void numberofIslandsCountUtil(int i, int j)
	{
		visited[i][j]=true;
		int a[]= new int[] {-1,-1,-1, 0, 0, 1, 1, 1};
		int b[]= new int[] {-1, 0 ,1,-1, 1,-1, 0, 1};
		for(int k=0;k<8;k++)
		{
			if(isSafe(i+a[k], j+b[k])==true)
			{
				numberofIslandsCountUtil(i+a[k], j+b[k]);
			}
		}
	}
	static int numberofIslandsCount(int arr[][])
	{
		//track visited path
		for(int i=0;i<5;i++)
			for(int j=0;j<5;j++)
				visited[i][j]=false;
		
		//visit the array
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<5;j++)
			{
				if(visited[i][j]==false && arr[i][j]==1)
				{
					numberofIslandsCountUtil(i,j);
					++count;
				}
			}
		}
		return count;
	}
	public static void main(String[] args) {
		
		
	 numberofIslandsCount(arr);
	 System.out.println("Number of islands are: "+count);
	}

}
