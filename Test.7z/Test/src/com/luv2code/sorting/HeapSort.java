package com.luv2code.sorting;
/*
 * https://www.geeksforgeeks.org/java-program-for-heap-sort/
 */
public class HeapSort {
	public void sort(int arr[])
	{
		int n = arr.length;
		//Create heap(rearrange array)
		for(int i = n/2-1; i >=0; i--)
			heapify(arr, n , i);
		
		// One by one extract an element from heap
		for(int i = n-1 ;i>=0; i--)
		{
			// Move current root to end 
            int temp = arr[0]; 
            arr[0] = arr[i]; 
            arr[i] = temp; 
  
            // call max heapify on the reduced heap 
            heapify(arr, i, 0); 
		}
	}
	public void heapify(int arr[], int n , int i)
	{
		int largest = i, l, r;
		l = 2*largest+1;
		r = 2*largest+2;
		
		if(l<n && arr[largest] < arr[l])
			largest = l;
		
		if(r < n && arr[largest] < arr[r])
			largest =r;
		
		// If largest is not root 
		if(largest != i)
		{
			int temp = arr[i];
			arr[i] = arr[largest];
			arr[largest] = temp;			
			heapify(arr, n , largest);
		}
	}
	public static void printArray(int arr[])
	{
		int n = arr.length;
		for(int i=0; i< n; i++)
			System.out.println(arr[i]+" ");
			
	}
	public static void main(String[] args) {
		int arr[] = {12, 11, 13, 5, 6, 7}; 
        int n = arr.length; 
  
        HeapSort ob = new HeapSort(); 
        ob.sort(arr); 
  
        System.out.println("Sorted array is"); 
        printArray(arr); 
	}
}
