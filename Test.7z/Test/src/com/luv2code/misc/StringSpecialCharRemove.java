package com.luv2code.misc;

public class StringSpecialCharRemove {
	static char str1[]= new char[]{'D', '@', 'E', '&', 'F', '$'};
	static char str2[]= new char[]{'@', '&', '$'};
	static int specialCharRemove()
	{
		int count1=0,count2=0;
		while(count1<str1.length)
		{
			boolean flag=false;
			
			for(int i=0;i<str2.length;i++)
			{
				if(str1[count1]==str2[i])
				{
					flag=true;
					break;
				}
			}
			if(flag==false)
			{
				str1[count2]=str1[count1];
				count2++; 
			}
			count1++;
		}
		return count2;//count2 will have new string length after removing special chars.
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int newlength=specialCharRemove();
		for(int i=0;i<newlength;i++)
			System.out.println(str1[i]);
	}

}
