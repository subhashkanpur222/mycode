package com.luv2code.misc;

public class StringRearrangeSameChar {
	static char str1[]= new char[]{'A', 'A', 'A', 'B', 'C'};
	static void stringSameCharRemove()
	{
		int count1=1;
		while(count1<str1.length)
		{
			if(str1[count1-1]==str1[count1])
			{
				for(int i=count1+1;i<str1.length;i++)
				{
					if(str1[count1]!=str1[i])
					{
						char temp;
						temp=str1[i];
						str1[i]=str1[count1];
						str1[count1]=temp;
						break;
					}
				}
			}
			
			count1++;
		}
	}
	public static void main(String[] args) {
		stringSameCharRemove();
		for(int i=0;i<str1.length;i++)
			System.out.println(str1[i]);
	}

}
