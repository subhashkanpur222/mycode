package com.luv2code.misc;

class ThreadA extends Thread
{
	Thread t1;

	public ThreadA(Thread t1)
	{
		this.t1=t1;
	}
	public   void run()
	{
		synchronized(this)
		{
		for (int i=0;i<10;i=i+2)
		{
			
			try {
				this.wait();
			} catch (InterruptedException e) {
			}
			System.out.println(i);
			this.notify();
		}
		}
	}
	
}
public class ThreadDemo1  {

	public static void main(String[] args) throws InterruptedException {
		Thread t1=Thread.currentThread();
		ThreadA t= new ThreadA(t1);
		t.start();
		synchronized(t)
		{
		for (int i=1;i<10;i=i+2)
		{
			t.notify();
			System.out.println(i);
			t1.wait();
		}
	}
	}
}
