package com.luv2code.stack;

import java.util.Stack;

public class StackImplementaionWithGetMin extends Stack{
	Stack<Integer> myStack = new Stack<Integer>();
	public void mypush(int item)
	{
		if(isEmpty() == true)
		{
			System.out.println("Stack is empty");
			myStack.push(item);
			push(item);
		}
		else
		{
			int value = myStack.peek();
			if(value> item)
				myStack.push(item);
			else
				myStack.push(value);
			
			push(item);
			
		}
		
	}
	public Integer  pop()
	{
		int item=0;
		if(!this.isEmpty())
		{
			item = this.pop();
			myStack.pop();
		}
		else
			System.out.println("Stack is empty");
		
		return item;		
	}
	public int getMin()
	{
		int item = 0;
		item=this.myStack.peek();
		return item;
	}
	public static void main(String[] args) {
		StackImplementaionWithGetMin s = new StackImplementaionWithGetMin();
		s.mypush(11);
		s.mypush(30);
		s.mypush(41);
		//s.pop();
		System.out.println(s.getMin());
	}

}
