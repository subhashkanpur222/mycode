package com.luv2code.multithreading;

/*
 * http://tutorials.jenkov.com/java-util-concurrent/blockingqueue.html
 */
public class BlockingQueueArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
