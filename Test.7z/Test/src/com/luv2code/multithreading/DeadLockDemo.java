package com.luv2code.multithreading;
//  http://jaroslav-sedlacek.blogspot.com/2011/03/deadlock-despite-consistent-lock.html

public class DeadLockDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
