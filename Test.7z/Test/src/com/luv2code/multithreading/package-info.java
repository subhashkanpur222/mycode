/**
 * 
 */
/**
 * @author subhasku
 * For concurreny doc and example refer
 * https://coderanch.com/t/617241/java/Java-multithreading-exercies
 * 
 * https://www.geeksforgeeks.org/tag/java-multithreading/
 */
package com.luv2code.multithreading;