package DynamicProgramming;

//Program to count number of ways we can reach a score with given points

public class CountWaystoReachScore {
	static int waysToReachScore(int points[], int N)
	{
		int ways[] = new int[N+1];
		ways[0] = 1;
		
		for(int s:points)
		{
			for(int j = s; j <= N; j++)
				ways[j] += ways[j-s];
		}
		
		return ways[N];
	}	
	public static void main(String[] args) {
		int points[] = {3,5,10}; 
		int n = 20; 
	    System.out.println("Count for "+n+" is "+waysToReachScore(points, n)); 
	    n = 13; 
	    System.out.println("Count for "+n+" is "+waysToReachScore(points, n));
	}

}
