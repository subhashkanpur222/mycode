
public class RatInMaze {
	public void solveRatMaze(int maze[][])
	{
		
	}
	public static void main(String[] args) {
		RatInMaze rat=new RatInMaze();
		int maze[][] = {{1, 0, 0, 0},
	            		{1, 1, 0, 1},
	            		{0, 1, 0, 0},
	            		{1, 1, 1, 1}
	        };
		rat.solveRatMaze(maze);
	}

}
